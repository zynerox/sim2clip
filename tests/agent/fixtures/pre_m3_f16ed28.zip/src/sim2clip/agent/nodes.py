"""Meaningful state transitions: planning, validation, MCP execution and reporting."""

import json

from langchain_core.messages import HumanMessage, ToolMessage, messages_to_dict
from pydantic import ValidationError

from sim2clip.agent.artifacts import ArtifactStore, json_bytes
from sim2clip.agent.mcp_client import SimulationMCPClient, ToolFailure, parse_result
from sim2clip.agent.planner import Planner, PlannerFailure
from sim2clip.agent.state import JSONDict, SimulationAgentState
from sim2clip.agent.validation import experiment_design, validate_request, validate_response
from sim2clip.simulation.schemas import ComparisonResult, SimulationResult


def decision(
    state: SimulationAgentState,
    node: str,
    action: str,
    reason: str,
    *,
    round_number: int | None = None,
) -> list[JSONDict]:
    return [
        {
            "node": node,
            "round": state["planning_round"] if round_number is None else round_number,
            "action": action,
            "reason": reason,
        }
    ]


def failure(state: SimulationAgentState, node: str, message: str) -> JSONDict:
    return {
        "status": "failed",
        "next_action": "end",
        "errors": [{"node": node, "message": message}],
        "decision_history": decision(state, node, "stop", message),
    }


def replan(state: SimulationAgentState, category: str, feedback: JSONDict) -> JSONDict:
    counts = dict(state["retry_counts"])
    policy_key = "parameter_replans" if category == "parameters" else "result_replans"
    if counts[category] >= state["policy"][policy_key]:
        return {**failure(state, category, "Replanning budget exhausted"), "feedback": feedback}
    counts[category] += 1
    return {
        "retry_counts": counts,
        "feedback": feedback,
        "status": "replanning",
        "next_action": "planner",
        "decision_history": decision(state, category, "replan", feedback["reason"]),
    }


def tool_message(call: JSONDict, payload: JSONDict, *, error: bool = False) -> list[JSONDict]:
    return messages_to_dict(
        [
            ToolMessage(
                content=json.dumps(payload, ensure_ascii=False),
                tool_call_id=call["id"],
                status="error" if error else "success",
            )
        ]
    )


class AgentNodes:
    def __init__(self, planner: Planner, mcp: SimulationMCPClient, store: ArtifactStore) -> None:
        self.planner, self.mcp, self.store = planner, mcp, store

    async def plan(self, state: SimulationAgentState) -> JSONDict:
        round_number = state["planning_round"] + 1
        try:
            answer = await self.planner.plan(state, self.mcp.tools)
            calls: list[JSONDict] = []
            for index, raw in enumerate(answer.tool_calls):
                internal_id = f"r{round_number}-c{index}"
                calls.append(
                    {
                        "id": internal_id,
                        "provider_id": raw.get("id"),
                        "name": raw["name"],
                        "arguments": raw["args"],
                    }
                )
                raw["id"] = internal_id
            explanation = (
                answer.content
                if isinstance(answer.content, str)
                else json.dumps(answer.content, ensure_ascii=False)
            )
            messages = messages_to_dict([answer])
            if not state["messages"]:
                messages = messages_to_dict([HumanMessage(content=state["user_query"])]) + messages
            return {
                "experiment_goal": state["experiment_goal"]
                or answer.additional_kwargs.get("planning_metadata", {}).get(
                    "experiment_goal", state["user_query"]
                ),
                "experiment_plan": {
                    "reason": explanation,
                    "calls": calls,
                    "metadata": answer.additional_kwargs.get("planning_metadata", {}),
                },
                "planning_round": round_number,
                "planner_mode": self.planner.mode,
                "messages": messages,
                "status": "planning",
                "decision_history": decision(
                    state, "planner", "propose", explanation, round_number=round_number
                ),
            }
        except PlannerFailure as exc:
            feedback = {"code": exc.code, "reason": str(exc)}
            attempted = state.copy()
            attempted["planning_round"] = round_number
            update = (
                replan(attempted, "parameters", feedback)
                if exc.repairable
                else failure(attempted, "planner", str(exc))
            )
            return {
                **update,
                "errors": [
                    *update.get("errors", []),
                    {"node": "planner", "code": exc.code, "message": str(exc)},
                ],
                "planning_round": round_number,
                "planner_mode": self.planner.mode,
                "feedback": feedback,
            }
        except Exception as exc:
            # No fabricated fallback plan on a model/provider failure.
            return {
                **failure(state, "planner", f"Planner failed: {type(exc).__name__}: {exc}"),
                "planning_round": round_number,
                "planner_mode": self.planner.mode,
            }

    def parameters(self, state: SimulationAgentState) -> JSONDict:
        raw_calls: list[JSONDict] = state["experiment_plan"].get("calls", [])
        try:
            if not 1 <= len(raw_calls) <= state["policy"]["maximum_batch_calls"]:
                raise ValueError(
                    "Planner must select a bounded, nonempty batch of simulation tools"
                )
            calls: list[JSONDict] = []
            for raw in raw_calls:
                arguments, cost = validate_request(raw["name"], raw["arguments"])
                calls.append({**raw, "arguments": arguments, "customer_runs": cost})
            design = experiment_design(calls)
            if any(word in state["user_query"].lower() for word in ("比较", "compare", " vs ")):
                if len(design["cashiers"]) < 2:
                    raise ValueError(
                        "User requested a comparison; at least two cashier groups required"
                    )
            previous = state["design"]
            if previous is not None:
                if any(design[key] != previous[key] for key in ("cashiers", "workload")):
                    raise ValueError("Replanning changed the locked workload or cashier groups")
                if not set(previous["seeds"]).issubset(design["seeds"]):
                    raise ValueError("Replanning must retain previously selected seeds")
            remaining = state["policy"]["maximum_customer_runs"] - state["customer_runs"]
            if sum(call["customer_runs"] for call in calls) > remaining:
                raise ValueError("Plan exceeds the remaining customer-run budget")
            if len(state["tool_calls"]) + len(calls) > state["policy"]["maximum_tool_calls"]:
                raise ValueError("Plan exceeds the remaining tool-call budget")
        except (ValidationError, ValueError, KeyError, TypeError) as exc:
            feedback = {"code": "INVALID_PARAMETERS", "reason": str(exc)}
            replies = [
                reply for call in raw_calls for reply in tool_message(call, feedback, error=True)
            ]
            return {**replan(state, "parameters", feedback), "messages": replies}
        return {
            "validated_request": calls,
            "design": design,
            "call_cursor": 0,
            "status": "executing",
            "next_action": "executor",
            "decision_history": decision(
                state,
                "parameter_validator",
                "execute",
                "Shared schemas, fair workload and work budgets validated",
            ),
        }

    async def execute(self, state: SimulationAgentState) -> JSONDict:
        call = state["validated_request"][state["call_cursor"]]
        attempt = sum(item["id"] == call["id"] for item in state["tool_calls"]) + 1
        history: JSONDict = {**call, "attempt": attempt, "round": state["planning_round"]}
        if (
            len(state["tool_calls"]) >= state["policy"]["maximum_tool_calls"]
            or state["customer_runs"] + call["customer_runs"]
            > state["policy"]["maximum_customer_runs"]
        ):
            return failure(state, "executor", "Execution budget exhausted")
        try:
            reference = self.store.cached(state["run_id"], call)
            cached = reference is not None
            if reference is None:
                payload = await self.mcp.call(call["name"], call["arguments"])
                reference = self.store.save_response(state["run_id"], call, payload)
            result = parse_result(call["name"], self.store.load(reference))
        except ToolFailure as exc:
            history.update(status="error", error=exc.to_dict())
            counts = dict(state["retry_counts"])
            update: JSONDict = {
                "tool_calls": [history],
                "customer_runs": state["customer_runs"] + call["customer_runs"],
            }
            if exc.retryable and counts["tools"] < state["policy"]["tool_retries"]:
                counts["tools"] += 1
                if exc.code == "TRANSPORT_ERROR":
                    try:
                        await self.mcp.reconnect()
                    except Exception:
                        return {**update, **failure(state, "executor", "MCP reconnect failed")}
                return {
                    **update,
                    "retry_counts": counts,
                    "next_action": "executor",
                    "decision_history": decision(state, "executor", "retry", exc.code),
                }
            if exc.code == "INVALID_PARAMETERS":
                # Complete the entire AI tool-call batch before another model turn.
                pending = state["validated_request"][state["call_cursor"] :]
                replies = [
                    reply
                    for item in pending
                    for reply in tool_message(item, exc.to_dict(), error=True)
                ]
                return {
                    **update,
                    **replan(state, "parameters", {"code": exc.code, "reason": str(exc)}),
                    "messages": replies,
                }
            return {
                **update,
                **failure(state, "executor", f"{exc.code}: {exc}"),
                "messages": tool_message(call, exc.to_dict(), error=True),
            }
        except (OSError, ValueError, ValidationError) as exc:
            history.update(status="error", error={"code": "ARTIFACT_ERROR", "message": str(exc)})
            return {
                **failure(state, "executor", f"Artifact/result error: {exc}"),
                "tool_calls": [history],
            }
        runs = result.results if isinstance(result, ComparisonResult) else (result,)
        references = {item["result_id"]: item for item in state["simulation_results"]}
        for run in runs:
            references[run.result_id] = {
                **reference,
                "result_id": run.result_id,
                "config": run.config.model_dump(mode="json"),
                "metrics": run.metrics.model_dump(mode="json"),
            }
        comparison = state["comparison_result"]
        compact: JSONDict
        if isinstance(result, ComparisonResult):
            comparison = {
                **reference,
                "comparison_id": result.comparison_id,
                "seeds": list(result.seeds),
                "summaries": [summary.model_dump(mode="json") for summary in result.summaries],
                "winner_cashiers": list(result.winner_cashiers),
            }
            compact = {
                "comparison_id": result.comparison_id,
                "seeds": list(result.seeds),
                "summaries": comparison["summaries"],
            }
        else:
            compact = {
                "result_id": result.result_id,
                "config": result.config.model_dump(mode="json"),
                "metrics": result.metrics.model_dump(mode="json"),
            }
        cursor = state["call_cursor"] + 1
        history.update(
            status="success",
            response=reference,
            cached=cached,
            result_ids=[run.result_id for run in runs],
        )
        return {
            "tool_calls": [history],
            "simulation_results": list(references.values()),
            "comparison_result": comparison,
            "call_cursor": cursor,
            "customer_runs": state["customer_runs"] + call["customer_runs"],
            "messages": tool_message(call, compact),
            "next_action": "executor"
            if cursor < len(state["validated_request"])
            else "result_validator",
            "decision_history": decision(
                state, "executor", "cached" if cached else "tool_success", call["name"]
            ),
        }

    def results(self, state: SimulationAgentState) -> JSONDict:
        current = [
            item
            for item in state["tool_calls"]
            if item["round"] == state["planning_round"] and item["status"] == "success"
        ]
        try:
            comparisons: list[ComparisonResult] = []
            for item in current:
                result = parse_result(item["name"], self.store.load(item["response"]))
                validate_response(item["name"], item["arguments"], result)
                if isinstance(result, ComparisonResult):
                    comparisons.append(result)
            if not current:
                raise ValueError("No successful tool evidence")
        except (ValueError, OSError, KeyError) as exc:
            feedback = {"code": "INVALID_EVIDENCE", "reason": str(exc)}
            return {
                **replan(state, "results", feedback),
                "validation_result": {"valid": False, "sufficient": False, **feedback},
            }
        minimum = state["policy"]["minimum_comparison_seeds"]
        if len((state["design"] or {}).get("cashiers", [])) > 1:
            complete = bool(comparisons) and set(
                config.cashiers for config in comparisons[-1].request.experiments
            ) == set((state["design"] or {}).get("cashiers", []))
            if not complete or len(comparisons[-1].seeds) < minimum:
                feedback = {
                    "code": "INSUFFICIENT_EVIDENCE",
                    "reason": f"Comparison requires at least {minimum} paired seeds",
                    "minimum_seeds": minimum,
                }
                return {
                    **replan(state, "results", feedback),
                    "validation_result": {"valid": True, "sufficient": False, **feedback},
                }
        validated = {
            "valid": True,
            "sufficient": True,
            "checked_calls": len(current),
            "checks": [
                "event_lifecycle",
                "FIFO",
                "capacity",
                "metrics",
                "request_provenance",
                "paired_samples",
                "comparison_statistics",
            ],
            "scope": "Descriptive finite-population results; no significance or real-world claim",
        }
        return {
            "validation_result": validated,
            "status": "validating",
            "next_action": "report",
            "decision_history": decision(
                state,
                "result_validator",
                "report",
                "Evidence is internally consistent and meets the declared seed policy",
            ),
        }

    def report(self, state: SimulationAgentState) -> JSONDict:
        if not state["validation_result"].get("sufficient"):
            return failure(state, "report", "Cannot report unvalidated evidence")
        # Read and recheck final evidence at the report boundary, including its checksum.
        try:
            result: SimulationResult | ComparisonResult
            if state["comparison_result"] is not None:
                result = parse_result(
                    "compare_simulations", self.store.load(state["comparison_result"])
                )
                assert isinstance(result, ComparisonResult)
                validate_response(
                    "compare_simulations", result.request.model_dump(mode="json"), result
                )
                rows = ["| 收银台 | 平均等待（秒） | 最大队长均值 |", "| --- | ---: | ---: |"]
                rows += [
                    f"| {s.cashiers} | {s.average_wait_time.mean:.2f} | "
                    f"{s.max_queue_length.mean:.2f} |"
                    for s in result.summaries
                ]
                conclusion = (
                    f"在这 {len(result.seeds)} 个配对种子的实验中，"
                    f"平均等待最短的配置为 {list(result.winner_cashiers)} 个收银台。"
                )
                provenance = f"种子：{list(result.seeds)}；comparison_id：{result.comparison_id}"
            else:
                rows = ["| 收银台 | 顾客 | 平均等待（秒） |", "| --- | ---: | ---: |"]
                for reference in state["simulation_results"]:
                    result = parse_result("run_simulation", self.store.load(reference))
                    assert isinstance(result, SimulationResult)
                    validate_response(
                        "run_simulation", result.config.model_dump(mode="json"), result
                    )
                    rows.append(
                        f"| {result.config.cashiers} | {result.config.customers} | "
                        f"{result.metrics.average_wait_time:.2f} |"
                    )
                conclusion = "单次有限顾客实验；当前结果用于描述该种子的观察。"
                provenance = "完整配置、种子、记录与事件见工具响应 JSON。"
        except (ValueError, OSError, KeyError) as exc:
            return failure(state, "report", f"Final evidence unavailable: {exc}")
        design = state["design"] or {}
        workload = design.get("workload", {})
        text = (
            "\n\n".join(
                [
                    "# Sim2Clip 实验报告",
                    f"用户问题：{state['user_query']}",
                    f"实验目标：{state['experiment_goal']}",
                    f"规划模式：{state['planner_mode']}。"
                    "所有实验数值来自 MCP Server 的 SimPy 计算。",
                    f"模型假设：共享 FIFO 队列，顾客 {workload.get('customers')}；"
                    f"指数到达间隔均值 {workload.get('mean_interarrival_time')} 秒，"
                    f"指数服务时长均值 {workload.get('mean_service_time')} 秒。",
                    "\n".join(rows),
                    conclusion,
                    provenance,
                    "已独立复核事件、人数守恒、FIFO、收银台容量及指标。配对实验共享顾客样本。最低种子数是证据预算策略，不能证明统计显著性或真实店铺表现。",
                ]
            )
            + "\n"
        )
        directory = self.store.run_dir(state["run_id"])
        completion = decision(
            state, "report", "complete", "Report generated exclusively from validated tool evidence"
        )
        artifacts: JSONDict = {
            "report": str(directory / "report.md"),
            "decisions": str(directory / "decisions.json"),
        }
        if isinstance(result, ComparisonResult):
            self.store.write(
                directory / "comparison.json", json_bytes(result.model_dump(mode="json"))
            )
            artifacts["comparison"] = str(directory / "comparison.json")
        else:
            artifacts["simulation_results"] = [item["path"] for item in state["simulation_results"]]
        self.store.write(directory / "report.md", text.encode("utf-8"))
        self.store.write(
            directory / "decisions.json", json_bytes(state["decision_history"] + completion)
        )
        return {
            "report": text,
            "status": "completed",
            "next_action": "end",
            "artifacts": artifacts,
            "decision_history": completion,
        }
