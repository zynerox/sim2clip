"""Atomic JSON receipts keep replay events out of every SQLite snapshot."""

import hashlib
import json
import os
from pathlib import Path

from sim2clip.agent.state import JSONDict


def json_bytes(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False).encode("utf-8")


class ArtifactStore:
    def __init__(self, root: Path) -> None:
        self.root = root.resolve()

    def run_dir(self, run_id: str) -> Path:
        return self.root / run_id

    def write(self, path: Path, data: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        with temporary.open("wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(path)

    def _receipt_path(self, run_id: str, call: JSONDict) -> Path:
        digest = hashlib.sha256(json_bytes([call["name"], call["arguments"]])).hexdigest()
        return self.run_dir(run_id) / f"{call['id']}-{digest}.receipt.json"

    def save_response(self, run_id: str, call: JSONDict, payload: JSONDict) -> JSONDict:
        receipt = self._receipt_path(run_id, call)
        path = receipt.with_name(receipt.name.replace(".receipt.json", ".json"))
        content = json_bytes(payload)
        self.write(path, content)
        reference = {"path": str(path), "sha256": hashlib.sha256(content).hexdigest()}
        self.write(
            receipt,
            json_bytes(
                {"name": call["name"], "arguments": call["arguments"], "reference": reference}
            ),
        )
        return reference

    def cached(self, run_id: str, call: JSONDict) -> JSONDict | None:
        receipt = self._receipt_path(run_id, call)
        if not receipt.exists():
            return None
        value = json.loads(receipt.read_text(encoding="utf-8"))
        if value["name"] != call["name"] or value["arguments"] != call["arguments"]:
            raise ValueError("Receipt arguments do not match the tool call")
        self.load(value["reference"])
        return dict(value["reference"])

    def load(self, reference: JSONDict) -> JSONDict:
        path = Path(reference["path"]).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError("Artifact reference is outside this run's artifact root")
        content = path.read_bytes()
        if hashlib.sha256(content).hexdigest() != reference["sha256"]:
            raise ValueError("Artifact checksum mismatch")
        value = json.loads(content)
        if not isinstance(value, dict):
            raise ValueError("Artifact must contain a JSON object")
        return value
