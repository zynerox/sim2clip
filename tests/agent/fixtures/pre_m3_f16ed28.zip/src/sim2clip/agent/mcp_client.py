"""MCP boundary. Never import or invoke simulation engine functions here."""

import json
import sys
from typing import Any

from mcp import Client
from mcp.client.stdio import StdioServerParameters
from mcp.types import Tool
from pydantic import ValidationError

from sim2clip.agent.state import JSONDict
from sim2clip.simulation.schemas import ComparisonResult, SimulationResult


class ToolFailure(Exception):
    def __init__(self, code: str, message: str, *, retryable: bool = False) -> None:
        super().__init__(message)
        self.code = code
        self.retryable = retryable

    def to_dict(self) -> JSONDict:
        return {"code": self.code, "message": str(self), "retryable": self.retryable}


def default_server() -> StdioServerParameters:
    return StdioServerParameters(command=sys.executable, args=["-m", "sim2clip.mcp_server"])


def parse_result(name: str, payload: JSONDict) -> SimulationResult | ComparisonResult:
    if name == "run_simulation":
        return SimulationResult.model_validate(payload)
    if name == "compare_simulations":
        return ComparisonResult.model_validate(payload)
    raise ToolFailure("UNKNOWN_TOOL", f"Unsupported simulation tool: {name}")


class SimulationMCPClient:
    def __init__(self, server: Any = None, *, timeout: float = 60.0) -> None:
        self.server = server if server is not None else default_server()
        self.timeout = timeout
        self.client: Client | None = None
        self.tools: list[Tool] = []

    async def __aenter__(self) -> "SimulationMCPClient":
        try:
            self.client = await Client(self.server, read_timeout_seconds=self.timeout).__aenter__()
            self.tools = (await self.client.list_tools()).tools
            if {tool.name for tool in self.tools} != {"run_simulation", "compare_simulations"}:
                raise ValueError("Server must expose the two Sim2Clip tools")
            return self
        except BaseException:
            await self.close()
            raise

    async def close(self) -> None:
        if self.client is not None:
            client, self.client = self.client, None
            await client.__aexit__(None, None, None)

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    async def call(self, name: str, arguments: JSONDict) -> JSONDict:
        if self.client is None:
            raise RuntimeError("MCP client is not open")
        try:
            response = await self.client.call_tool(name, arguments)
        except Exception as exc:
            # The tools are deterministic and idempotent. A transport failure can
            # be retried after reconnecting; deterministic engine errors cannot.
            raise ToolFailure("TRANSPORT_ERROR", type(exc).__name__, retryable=True) from exc
        payload = response.structured_content
        if payload is None:
            try:
                text = next(block.text for block in response.content if block.type == "text")
                payload = json.loads(text)
            except (StopIteration, ValueError) as exc:
                raise ToolFailure("INVALID_RESULT", "MCP response has no JSON object") from exc
        if not isinstance(payload, dict):
            raise ToolFailure("INVALID_RESULT", "MCP response must be an object")
        if response.is_error:
            error = payload.get("error", {})
            if not isinstance(error, dict):
                error = {}
            raise ToolFailure(
                str(error.get("code", "TOOL_ERROR")),
                str(error.get("message", "MCP tool failed")),
                retryable=error.get("retryable") is True,
            )
        try:
            return parse_result(name, payload).model_dump(mode="json")
        except ValidationError as exc:
            raise ToolFailure("INVALID_RESULT", "MCP output violates the shared schema") from exc

    async def reconnect(self) -> None:
        await self.close()
        await self.__aenter__()
